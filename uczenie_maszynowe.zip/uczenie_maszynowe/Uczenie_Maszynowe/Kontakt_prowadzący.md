tomasz.krzywicki@matman.uwm.edu.pl
